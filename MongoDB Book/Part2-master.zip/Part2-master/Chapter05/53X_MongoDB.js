var mongodb = require('mongodb');
var ObjectID = require('mongodb').ObjectID;
var server = new mongodb.Server('127.0.0.1', 27017, {});

var client = new mongodb.Db('mydatabase', server, {w: 1});
var tmpID = '';

client.open(function(err){
	if(err) throw err;
	client.collection('test_insert', function(err, collection){
		if(err) throw err;
		console.log('we are now able to perform queries.');
		collection.insert(
			{
				"title": "I like cake",
				"body": "It is quite good."
			},	
			{safe: true},
			function(err, documents){
				if(err) throw err;
				tmpID = documents.ops[0]._id;				
				console.log('Document ID is: ' + tmpID);
				var _id = ObjectID(tmpID.toString()); 
				collection.update(
					{_id: _id},
					{$set: {"title": "I ate too much cake"}},
					{safe:true},
					function(err){
						if (err) throw err;
						console.log("algo");
					}
				);
				"".toString();
			}
		);
	});
});

